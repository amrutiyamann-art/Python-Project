import { useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronDown,
  Database,
  Download,
  FileJson,
  FileSpreadsheet,
  Filter,
  Gauge,
  Layers3,
  Lightbulb,
  Menu,
  MoreHorizontal,
  Play,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  TerminalSquare,
  Upload,
  WandSparkles,
  X,
  Zap,
} from "lucide-react";
import * as XLSX from "xlsx";

type Issue = "clean" | "missing" | "duplicate" | "inconsistent";
type RecordRow = { id: string; name: string; category: string; amount: string; status: string; issue: Issue };
type Format = "CSV" | "JSON" | "MD";

const seedRows: RecordRow[] = [
  { id: "R-104", name: "Aarav Mehta", category: "Workshop", amount: "1200", status: "Ready", issue: "clean" },
  { id: "R-105", name: "Mira Shah", category: "Workshop", amount: "—", status: "Ready", issue: "missing" },
  { id: "R-106", name: "Kabir Iyer", category: "Lab Kit", amount: "850", status: "Pending", issue: "clean" },
  { id: "R-107", name: "Rhea Nair", category: "lab kit", amount: "850", status: "Pending", issue: "inconsistent" },
  { id: "R-108", name: "Dev Malhotra", category: "Field Trip", amount: "2400", status: "Ready", issue: "clean" },
  { id: "R-109", name: "Mira Shah", category: "Workshop", amount: "—", status: "Ready", issue: "duplicate" },
];

const issueMeta: Record<Issue, { label: string; short: string; color: string }> = {
  clean: { label: "Clean", short: "OK", color: "teal" },
  missing: { label: "Missing", short: "MISSING", color: "amber" },
  duplicate: { label: "Duplicate", short: "DUPLICATE", color: "violet" },
  inconsistent: { label: "Inconsistent", short: "CHECK", color: "rose" },
};

function Brand() {
  return <a href="#top" className="brand"><span className="brand-glyph"><i /><i /><i /></span><span>clean<span className="brand-green">slate</span></span></a>;
}

function Kicker({ children }: { children: React.ReactNode }) {
  return <div className="kicker"><span className="kicker-dot" />{children}</div>;
}

function recompute(rows: Omit<RecordRow, "issue">[]): RecordRow[] {
  return rows.map((row, index, list) => {
    const duplicate = list.findIndex(other => other.name === row.name) !== index;
    const missing = row.amount === "—" || row.amount.trim() === "";
    const inconsistent = list.some(other => other.category.toLowerCase() === row.category.toLowerCase() && other.category !== row.category);
    return { ...row, issue: missing ? "missing" : duplicate ? "duplicate" : inconsistent ? "inconsistent" : "clean" };
  });
}

export default function Home() {
  const [rows, setRows] = useState<RecordRow[]>(seedRows);
  const [scanned, setScanned] = useState(false);
  const [showCleaned, setShowCleaned] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | Issue>("all");
  const [format, setFormat] = useState<Format>("CSV");
  const [activeView, setActiveView] = useState<"data" | "profile">("data");
  const [fileName, setFileName] = useState("sample_records.csv");
  const [rules, setRules] = useState<string[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const counts = useMemo(() => ({
    missing: rows.filter(row => row.issue === "missing").length,
    duplicate: rows.filter(row => row.issue === "duplicate").length,
    inconsistent: rows.filter(row => row.issue === "inconsistent").length,
  }), [rows]);
  const issueTotal = counts.missing + counts.duplicate + counts.inconsistent;
  const health = rows.length ? Math.max(0, Math.round(((rows.length - issueTotal) / rows.length) * 100)) : 0;
  const totalValue = rows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0);
  const visibleRows = useMemo(() => rows.filter(row => {
    const matchesFilter = filter === "all" || row.issue === filter;
    const matchesQuery = `${row.id} ${row.name} ${row.category} ${row.status}`.toLowerCase().includes(query.toLowerCase());
    return matchesFilter && matchesQuery;
  }), [rows, filter, query]);

  const scan = () => { setScanned(true); setShowCleaned(false); };
  const cleanAll = () => {
    setRows(current => {
      const normalized = current.map(({ issue: _issue, ...row }) => ({
        ...row,
        category: row.category.trim().replace(/\b\w/g, letter => letter.toUpperCase()),
        amount: row.amount === "—" || row.amount.trim() === "" ? "0" : row.amount,
      }));
      const unique = normalized.filter((row, index, list) => list.findIndex(other => other.name.toLowerCase() === row.name.toLowerCase()) === index);
      return recompute(unique);
    });
    setRules(["Normalize categories", "Fill blank amounts", "Remove duplicates"]);
    setScanned(true);
    setShowCleaned(true);
  };
  const applyRule = (rule: "normalize" | "fill" | "dedupe") => {
    if (rule === "normalize") {
      setRows(current => recompute(current.map(({ issue: _issue, ...row }) => ({ ...row, category: row.category.trim().replace(/\b\w/g, letter => letter.toUpperCase()) }))));
      setRules(current => current.includes("Normalize categories") ? current : [...current, "Normalize categories"]);
    }
    if (rule === "fill") {
      setRows(current => recompute(current.map(({ issue: _issue, ...row }) => ({ ...row, amount: row.amount === "—" ? "0" : row.amount }))));
      setRules(current => current.includes("Fill blank amounts") ? current : [...current, "Fill blank amounts"]);
    }
    if (rule === "dedupe") {
      setRows(current => recompute(current.filter((row, index, list) => list.findIndex(other => other.name === row.name) === index).map(({ issue: _issue, ...row }) => row)));
      setRules(current => current.includes("Remove duplicates") ? current : [...current, "Remove duplicates"]);
    }
    setScanned(true);
    setShowCleaned(true);
  };

  const readFile = (file?: File) => {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      setUploadError("This browser-local demo accepts files up to 10 MB.");
      return;
    }
    setUploadError("");
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const raw = reader.result;
        const text = new TextDecoder().decode(raw as ArrayBuffer).replace(/^\uFEFF/, "");
        const looksLikeJson = file.type === "application/json" || /^[\s]*[\[{]/.test(text);
        const parsed = looksLikeJson
          ? JSON.parse(text)
          : (() => {
              const workbook = XLSX.read(raw, { type: "array" });
              const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
              if (!firstSheet) throw new Error("No worksheet");
              const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: "" });
              if (rows.length > 0) return rows;
              const values = XLSX.utils.sheet_to_json<unknown[]>(firstSheet, { header: 1, defval: "" });
              return values.filter(row => Array.isArray(row) && row.some(value => String(value).trim() !== "")).map((row, index) => ({
                id: row[0] ?? `R-${index + 1}`,
                name: row[1] ?? row[0] ?? "Unnamed record",
                category: row[2] ?? "Uncategorized",
                amount: row[3] ?? "—",
                status: row[4] ?? "Ready",
              }));
            })();
        const source = Array.isArray(parsed) ? parsed : parsed.records ?? parsed.data ?? parsed.rows ?? parsed.items;
        if (!Array.isArray(source) || source.length === 0) throw new Error("No rows");
        const normalized = source.map((item, index) => ({
          id: String(item?.id ?? item?.ID ?? item?.record ?? item?.Record ?? `R-${index + 1}`),
          name: String(item?.name ?? item?.Name ?? item?.fullName ?? item?.["full name"] ?? item?.customer ?? item?.Customer ?? "Unnamed record"),
          category: String(item?.category ?? item?.Category ?? item?.type ?? item?.Type ?? item?.group ?? "Uncategorized"),
          amount: String(item?.amount ?? item?.Amount ?? item?.value ?? item?.Value ?? item?.total ?? "—"),
          status: String(item?.status ?? item?.Status ?? item?.state ?? item?.State ?? "Ready"),
        }));
        setRows(recompute(normalized));
        setFileName(file.name);
        setScanned(true);
        setShowCleaned(false);
        setRules([]);
      } catch (error) {
        const detail = error instanceof Error && error.message !== "No rows" ? ` (${error.message})` : "";
        setUploadError(`Could not read this file. Check that it contains at least one data row${detail}.`);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const download = () => {
    const content = format === "JSON"
      ? JSON.stringify(rows, null, 2)
      : format === "MD"
        ? `# CleanSlate report\n\nRecords: ${rows.length}\nHealth: ${health}/100\n\n| Record | Name | Category | Amount | Quality |\n| --- | --- | --- | --- | --- |\n${rows.map(row => `| ${row.id} | ${row.name} | ${row.category} | ${row.amount} | ${issueMeta[row.issue].label} |`).join("\n")}`
        : ["id,name,category,amount,status,quality", ...rows.map(row => [row.id, row.name, row.category, row.amount, row.status, issueMeta[row.issue].label].join(","))].join("\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([content], { type: format === "JSON" ? "application/json" : "text/plain" }));
    link.download = `cleanslate-report.${format.toLowerCase()}`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  return <div className="dark-app" id="top">
    <header className="app-header">
      <Brand />
      <nav className={`main-nav ${mobileOpen ? "mobile-open" : ""}`}><a href="#workspace" onClick={() => setMobileOpen(false)}>Workspace</a><a href="#profile" onClick={() => setMobileOpen(false)}>Profile</a><a href="#recipe" onClick={() => setMobileOpen(false)}>Recipe</a><a href="#report" onClick={() => setMobileOpen(false)}>Export</a></nav>
      <div className="header-actions"><span className="free-badge"><span />Free · no account</span><button className="mobile-toggle" aria-label="Open navigation" onClick={() => setMobileOpen(current => !current)}><Menu size={19} /></button><a className="header-button" href="#workspace">Open workspace <ArrowRight size={14} /></a></div>
    </header>

    <main>
      <section className="dark-hero">
        <div className="hero-grid-glow" />
        <div className="hero-copy-dark"><Kicker>LOCAL DATA PREPARATION</Kicker><h1>Clean data.<br /><span>Clear results.</span></h1><p>Load your file, fix the issues, and download a clean copy.</p><div className="hero-buttons"><a className="primary-button" href="#workspace"><Play size={15} fill="currentColor" /> Clean my data</a><a className="quiet-link" href="#how-it-works">How it works <ArrowRight size={14} /></a></div><div className="hero-meta"><span><ShieldCheck size={14} /> Runs in your browser</span><span><Zap size={14} /> Free to use</span><span><Database size={14} /> Your file stays local</span></div></div>
        <div className="upload-card"><div className="upload-card-head"><div><span className="upload-eyebrow">START HERE</span><h3>Drop in one data file</h3></div><span className="upload-local"><ShieldCheck size={13} /> local</span></div><button className={`dropzone ${isDragging ? "dragging" : ""}`} onClick={() => fileRef.current?.click()} onDragOver={event => { event.preventDefault(); setIsDragging(true); }} onDragLeave={() => setIsDragging(false)} onDrop={event => { event.preventDefault(); setIsDragging(false); readFile(event.dataTransfer.files?.[0]); }}><span className="dropzone-icon"><Upload size={21} /></span><strong>{isDragging ? "Release to upload" : "Drag & drop or browse"}</strong><span>CSV, XLSX, XLS, or JSON · up to 10 MB</span><small>No account · no upload · stays in your browser</small></button><input ref={fileRef} className="file-input" type="file" accept="*/*" onChange={event => readFile(event.target.files?.[0])} />{uploadError && <p className="upload-error"><AlertTriangle size={13} /> {uploadError}</p>}<div className="upload-card-foot"><span><CheckCircle2 size={14} /> Automatic quality scan</span><span><Download size={14} /> Export when ready</span></div></div>
      </section>

      <section id="workspace" className="app-section workspace-dark"><div className="section-topline"><div><Kicker>01 / WORKSPACE</Kicker><h2>Clean your data. <span>Step by step.</span></h2></div><div className="workspace-actions"><span className="local-chip"><span />Local mode</span><button className="secondary-button" onClick={() => { setRows(seedRows); setFileName("sample_records.csv"); setRules([]); setScanned(false); setUploadError(""); }}><RefreshCw size={14} /> Reset</button></div></div><div className="workspace-layout">
        <div className="data-card dark-card"><div className="data-card-head"><div className="file-title"><span className="file-icon"><FileSpreadsheet size={16} /></span><div><strong>{fileName}</strong><span>{rows.length} rows · 5 columns</span></div></div><div className="data-head-actions"><button className={`view-tab ${activeView === "data" ? "selected" : ""}`} onClick={() => setActiveView("data")}>Data</button><button className={`view-tab ${activeView === "profile" ? "selected" : ""}`} onClick={() => setActiveView("profile")}>Profile</button><button className="square-button" aria-label="Import CSV, Excel, or JSON" onClick={() => fileRef.current?.click()}><Upload size={15} /></button></div></div>
          {activeView === "data" ? <><div className="data-toolbar"><div className="dark-search"><Search size={14} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search rows..." /></div><label className="dark-select"><Filter size={13} /><select value={filter} onChange={event => setFilter(event.target.value as "all" | Issue)}><option value="all">All quality states</option><option value="missing">Missing values</option><option value="duplicate">Duplicates</option><option value="inconsistent">Inconsistent entries</option><option value="clean">Clean only</option></select><ChevronDown size={13} /></label></div><div className="data-table-wrap"><table className="data-table"><thead><tr><th>Record</th><th>Name</th><th>Category</th><th>Amount</th><th>Status</th><th>Quality</th></tr></thead><tbody>{visibleRows.map(row => <tr key={row.id} className={showCleaned && row.issue === "clean" ? "cleaned-row" : ""}><td className="mono table-id">{row.id}</td><td>{row.name}</td><td>{showCleaned && row.issue === "inconsistent" ? "Lab Kit" : row.category}</td><td className={row.amount === "—" ? "empty-value" : ""}>{showCleaned && row.amount === "—" ? "0" : row.amount}</td><td><span className={`state-tag ${row.status.toLowerCase()}`}>{row.status}</span></td><td><span className={`quality-tag ${issueMeta[row.issue].color}`}>{showCleaned && row.issue !== "clean" ? <><Check size={11} /> Cleaned</> : issueMeta[row.issue].short}</span></td></tr>)}</tbody></table></div><div className="table-bottom"><span>Showing {visibleRows.length} of {rows.length} records</span><span><i className="legend amber" /> needs attention <i className="legend teal" /> validated</span></div></> : <div className="profile-view"><div className="profile-banner"><div><span className="profile-eyebrow">AUTO-PROFILE</span><h3>What your data is telling you</h3><p>Quality signals are calculated from the current local dataset.</p></div><Gauge size={28} /></div><div className="column-grid">{[{ name: "name", type: "text", value: "100% filled", width: 100, tone: "teal" }, { name: "category", type: "text", value: "2 variants", width: 65, tone: "violet" }, { name: "amount", type: "number", value: "1 blank", width: 82, tone: "amber" }, { name: "status", type: "label", value: "2 values", width: 74, tone: "rose" }].map(column => <div className="column-card" key={column.name}><div><span className="mono">{column.name}</span><small>{column.type}</small></div><strong>{column.value}</strong><div className="column-bar"><i className={column.tone} style={{ width: `${column.width}%` }} /></div></div>)}</div></div>}</div>
        <aside className="action-rail"><div className="rail-header"><span className="rail-eyebrow">QUALITY CENTER</span><span className="pulse-label"><i /> live</span></div><div className="health-meter"><div className="meter-ring"><strong>{health}</strong><span>/100</span></div><div><h3>{health >= 80 ? "Good foundation" : "Worth a quick clean"}</h3><p>{issueTotal} quality signals need attention.</p></div></div><button className="scan-button" onClick={scanned ? cleanAll : scan}>{scanned ? <><WandSparkles size={16} /> Clean my file</> : <><WandSparkles size={16} /> Run quality scan</>}</button>{scanned && <button className="rail-toggle" onClick={() => setShowCleaned(current => !current)}>{showCleaned ? <><X size={13} /> View original rows</> : <><Sparkles size={13} /> View cleaned rows</>}</button>}<div className="signal-list"><div className="signal-row"><span className="signal-icon amber"><AlertTriangle size={14} /></span><div><strong>Missing values</strong><small>Blank fields to review</small></div><b>{counts.missing}</b></div><div className="signal-row"><span className="signal-icon violet"><Layers3 size={14} /></span><div><strong>Duplicate rows</strong><small>Repeated records found</small></div><b>{counts.duplicate}</b></div><div className="signal-row"><span className="signal-icon rose"><RefreshCw size={14} /></span><div><strong>Inconsistent entries</strong><small>Labels to standardize</small></div><b>{counts.inconsistent}</b></div></div><div className="rail-footer"><ShieldCheck size={15} /><span>Private by design<br /><b>No account. No upload.</b></span></div></aside>
      </div></section>

      <section id="how-it-works" className="app-section process-dark"><div className="section-topline"><div><Kicker>02 / THE WORKFLOW</Kicker><h2>A clear path from <span>raw to ready.</span></h2></div><p className="section-description">Follow four simple steps: add a file, check it, fix the issues, and export the result.</p></div><div className="workflow-line"><div className="workflow-step complete"><span className="workflow-number">01</span><span className="workflow-icon"><Upload size={17} /></span><strong>Add a file</strong><small>Choose CSV or JSON</small></div><div className="workflow-connector complete" /><div className="workflow-step active"><span className="workflow-number">02</span><span className="workflow-icon"><Gauge size={17} /></span><strong>Check the profile</strong><small>Find blanks and duplicates</small></div><div className="workflow-connector" /><div className="workflow-step"><span className="workflow-number">03</span><span className="workflow-icon"><WandSparkles size={17} /></span><strong>Fix the issues</strong><small>Apply suggested changes</small></div><div className="workflow-connector" /><div className="workflow-step"><span className="workflow-number">04</span><span className="workflow-icon"><Download size={17} /></span><strong>Download the result</strong><small>Export CSV, JSON, or MD</small></div></div></section>

      <section id="recipe" className="app-section recipe-dark"><div className="section-topline"><div><Kicker>03 / FIX ISSUES</Kicker><h2>Fix what needs fixing. <span>One action at a time.</span></h2></div><span className="recipe-count"><span>{rules.length}</span> applied</span></div><div className="recipe-grid"><div className="suggestion-card"><div className="suggestion-top"><span className="suggestion-icon"><Lightbulb size={17} /></span><div><span className="suggestion-label">SUGGESTION</span><h3>Normalize category labels</h3></div><span className="confidence">98% match</span></div><p>“Lab Kit” and “lab kit” refer to the same category. Standardize casing to keep grouping reliable.</p><button className="recipe-button" onClick={() => applyRule("normalize")} disabled={rules.includes("Normalize categories")}>{rules.includes("Normalize categories") ? <><Check size={14} /> Applied</> : <><Plus size={14} /> Apply fix</>}</button></div><div className="suggestion-card"><div className="suggestion-top"><span className="suggestion-icon amber"><Lightbulb size={17} /></span><div><span className="suggestion-label">SUGGESTION</span><h3>Fill blank amounts</h3></div><span className="confidence">94% match</span></div><p>One record has no amount. Fill it with 0 to keep numeric summaries and charts consistent.</p><button className="recipe-button" onClick={() => applyRule("fill")} disabled={rules.includes("Fill blank amounts")}>{rules.includes("Fill blank amounts") ? <><Check size={14} /> Applied</> : <><Plus size={14} /> Apply fix</>}</button></div><div className="suggestion-card"><div className="suggestion-top"><span className="suggestion-icon violet"><Layers3 size={17} /></span><div><span className="suggestion-label">SUGGESTION</span><h3>Remove duplicate records</h3></div><span className="confidence">91% match</span></div><p>Mira Shah appears twice with the same identifying fields. Keep the first occurrence and remove the repeated row.</p><button className="recipe-button" onClick={() => applyRule("dedupe")} disabled={rules.includes("Remove duplicates")}>{rules.includes("Remove duplicates") ? <><Check size={14} /> Applied</> : <><Plus size={14} /> Apply fix</>}</button></div></div></section>

      <section id="report" className="app-section report-dark"><div className="report-top"><div><Kicker>04 / EXPORT</Kicker><h2>Leave with a file <span>you can trust.</span></h2></div><div className="report-controls"><div className="format-switch">{(["CSV", "JSON", "MD"] as const).map(item => <button key={item} className={format === item ? "active" : ""} onClick={() => setFormat(item)}>{item}</button>)}</div><button className="export-button" onClick={download}><Download size={15} /> Download {format}</button></div></div><div className="report-summary"><div><span className="summary-label">CURRENT HEALTH</span><strong>{health}<small>/100</small></strong><div className="summary-progress"><i style={{ width: `${health}%` }} /></div></div><div><span className="summary-label">ROWS</span><strong>{rows.length}</strong><small>records in view</small></div><div><span className="summary-label">ISSUES</span><strong>{issueTotal}</strong><small>signals to review</small></div><div><span className="summary-label">VALUE</span><strong>₹ {totalValue.toLocaleString("en-IN")}</strong><small>total amount</small></div></div></section>

      <section className="free-strip"><div className="free-strip-icon"><Sparkles size={19} /></div><div><strong>Clean data without the overhead.</strong><span>Built for local files, quick decisions, and a workflow that stays understandable.</span></div><a href="#workspace">Open workspace <ArrowRight size={14} /></a></section>
    </main>
    <footer className="dark-footer"><Brand /><span>Data preparation, kept simple.</span><span>CSV · JSON · browser-local</span></footer>
  </div>;
}
